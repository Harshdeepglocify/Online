<?php
	include "../config/config.php";
      $delimiter = ",";

      $f= fopen( 'php://output', 'w' );
                

      //set column headers
      $fields = array('Nickname','Username','Teacher', 'School','Last Active');
      fputcsv($f, $fields, $delimiter);
       
      //output each row of the data, format line as csv and write to file pointer
    	
	$query = "SELECT * FROM user WHERE `role` ='student' AND `license` ='".$_SESSION['User']['license']."'  AND `is_admin` != '1' ORDER BY firstname ASC";
	

      $query_result = mysqli_query($con, $query);

            if (mysqli_num_rows($query_result) > 0 ) {

                while ($student_row = mysqli_fetch_assoc($query_result)) {
                
                	$firstname =  ucfirst(base64_decode($student_row['firstname']));
                    $nickname = $firstname;
            		$username = base64_decode($student_row['username']);
            		$teacher_name = base64_decode($student_row['teacher_name']);
            		$organization = base64_decode($student_row['organization']);
                    $username =  base64_decode($student_row['username']);

                    $args = array(
                        'teacher_code' => $student_row['teacher'],
                        'role' => 'teacher',
                    );
                    $teacher_data = get_users($args);
                    if(!empty($teacher_data)){
                        $teacher_name = isset($teacher_data[0]['username']) ? base64_decode($teacher_data[0]['username']) : '';
                    }
                    $email = isset( $student_row['email'] )?base64_decode( $student_row['email'] ): "";
                    $license =$student_row['license'];

                    $activity = !empty($student_row['login']) ? getTimtstampDiff($student_row['login']):"";

		            $fields_value = array($nickname, $username,$teacher_name, $organization,$activity);
		            fputcsv($f, $fields_value , $delimiter);
		        }

            }
     
      fclose( $f );
      return 
     ?>